# Django SQL To REST Microservices Common Lib

This package provides common functions to Django SQL To REST Microservices ecosystem.
